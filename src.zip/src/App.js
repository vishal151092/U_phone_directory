
import './App.css';
import Header from './components/Header';
import ContactList from './components/ContactList';
import {React} from 'react';
import AddContact from './components/AddContact';

function App() {
 
  return (
    <>
      <Header title='Phone Directory' subHeading='Upgrad' />
      <AddContact data='test data'/>
      <ContactList />
      
      {/* <Header title='PCO' /> */}
      

    </>
    
  );
}

export default App;
