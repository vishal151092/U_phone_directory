import {Component} from 'react';

class AddContact extends Component{

    constructor(props){
        super(props);

    }

    render(){
        return (
            <>
            <h2>Class Component</h2>
            <h3>{this.props.data}</h3>
            </>
        )
    }
}

export default AddContact;