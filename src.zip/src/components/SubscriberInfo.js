
export default function SubscriberInfo(prop){
    //let dataList =prop.data
    return(
        <>
            <div>
            {prop.dataList.map((contact,index)=> {
                    return <div key={index} className='data-container'>
                                    <span >{contact.name}</span><span>{contact.phone}</span>
                                    <button className='delete-btn'>Delete</button>
                                </div>
                        
                }) }
            </div>
        </>
    )
}