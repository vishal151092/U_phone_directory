import './ContactList.css';
import SubscriberInfo from './SubscriberInfo';

export default function ContactList(){

let dataList = [
    {
        id: 1,
        name: 'Jack',
        phone: '84300032223'
    },
    {
        id: 2,
        name: 'Jill',
        phone: '45959684564'
    },
    {
        id: 3,
        name: 'Shilpa',
        phone: '09748576456'
    },
    {
        id: 4,
        name: 'Narendra',
        phone: '43658537353'
    },
    {
        id: 5,
        name: 'Mota Bhai',
        phone: '766587865787'
    }
]


    return(
        <div className='container' >
            <div >
                <button className='button'>Add</button>
            </div>
            <div className='list-container'>
                <span>NAME</span> 
                <span>PHONE</span>
                <span>&nbsp;</span>
                
            </div>
            <div >
                {/* <span>{dataList[0].name}</span>
                <span>{dataList[0].phone}</span> */}
                
                {/* {dataList.map((contact,index)=> {
                    return <div key={index} className='data-container'>
                                    <span >{contact.name}</span><span>{contact.phone}</span>
                                    <button className='delete-btn'>Delete</button>
                                </div>
                        
                }) } */}

                <SubscriberInfo dataList={dataList} />
            </div>
        </div>
    );
}
